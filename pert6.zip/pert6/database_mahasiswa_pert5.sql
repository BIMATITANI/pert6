-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               10.1.34-MariaDB - mariadb.org binary distribution
-- Server OS:                    Win32
-- HeidiSQL Version:             10.1.0.5464
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


-- Dumping database structure for database_mahasiswa
CREATE DATABASE IF NOT EXISTS `database_mahasiswa` /*!40100 DEFAULT CHARACTER SET utf8 COLLATE utf8_bin */;
USE `database_mahasiswa`;

-- Dumping structure for table database_mahasiswa.data_dosen
CREATE TABLE IF NOT EXISTS `data_dosen` (
  `KodeDosen` char(5) COLLATE utf8_bin NOT NULL,
  `NamaDosen` varchar(100) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`KodeDosen`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- Dumping data for table database_mahasiswa.data_dosen: ~3 rows (approximately)
/*!40000 ALTER TABLE `data_dosen` DISABLE KEYS */;
INSERT INTO `data_dosen` (`KodeDosen`, `NamaDosen`) VALUES
	('67123', 'PANJUL CAHYADI'),
	('67999', 'HARIYONO KUSUMA'),
	('68686', 'KARTONO SANTOSO');
/*!40000 ALTER TABLE `data_dosen` ENABLE KEYS */;

-- Dumping structure for table database_mahasiswa.data_jadwal
CREATE TABLE IF NOT EXISTS `data_jadwal` (
  `Serial` int(11) NOT NULL AUTO_INCREMENT,
  `Semester` char(5) COLLATE utf8_bin NOT NULL DEFAULT '20151',
  `KodeMakul` varchar(6) COLLATE utf8_bin NOT NULL,
  `KodeKelas` char(1) COLLATE utf8_bin NOT NULL,
  `Hari` char(1) COLLATE utf8_bin NOT NULL DEFAULT '1',
  `Jam1` tinyint(4) NOT NULL DEFAULT '7',
  `Jam2` tinyint(4) NOT NULL DEFAULT '8',
  `Ruang` varchar(6) COLLATE utf8_bin NOT NULL,
  `MaxKursi` tinyint(4) NOT NULL DEFAULT '30',
  `KodeDosen` char(5) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`Serial`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- Dumping data for table database_mahasiswa.data_jadwal: ~6 rows (approximately)
/*!40000 ALTER TABLE `data_jadwal` DISABLE KEYS */;
INSERT INTO `data_jadwal` (`Serial`, `Semester`, `KodeMakul`, `KodeKelas`, `Hari`, `Jam1`, `Jam2`, `Ruang`, `MaxKursi`, `KodeDosen`) VALUES
	(1, '20191', 'IN112', 'A', '1', 7, 10, 'FTI333', 2, '67123'),
	(2, '20191', 'IN112', 'B', '1', 10, 13, 'FTI333', 5, '67999'),
	(3, '20191', 'IN112', 'C', '2', 10, 13, 'FTI456', 10, '68686'),
	(4, '20191', 'IN112', 'D', '3', 13, 16, 'FTI442', 1, '67999'),
	(5, '20191', 'IN212', 'A', '1', 8, 11, 'FTI512', 30, '68686'),
	(6, '20191', 'IN212', 'B', '2', 10, 13, 'FTI356', 30, '67123'),
	(7, '20191', 'IN315', 'A', '2', 13, 16, 'FTI225', 30, '67123');
/*!40000 ALTER TABLE `data_jadwal` ENABLE KEYS */;

-- Dumping structure for table database_mahasiswa.data_list_peserta
CREATE TABLE IF NOT EXISTS `data_list_peserta` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `SerialJadwal` int(11) NOT NULL DEFAULT '0',
  `NIM` char(9) COLLATE utf8_bin NOT NULL,
  `Status` char(1) COLLATE utf8_bin NOT NULL DEFAULT 'B',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- Dumping data for table database_mahasiswa.data_list_peserta: ~0 rows (approximately)
/*!40000 ALTER TABLE `data_list_peserta` DISABLE KEYS */;
INSERT INTO `data_list_peserta` (`Id`, `SerialJadwal`, `NIM`, `Status`) VALUES
	(1, 1, '672020111', 'B'),
	(2, 1, '672020001', 'B');
/*!40000 ALTER TABLE `data_list_peserta` ENABLE KEYS */;

-- Dumping structure for table database_mahasiswa.data_login
CREATE TABLE IF NOT EXISTS `data_login` (
  `NIM` varchar(9) COLLATE utf8_bin NOT NULL,
  `password` varchar(25) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`NIM`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- Dumping data for table database_mahasiswa.data_login: ~3 rows (approximately)
/*!40000 ALTER TABLE `data_login` DISABLE KEYS */;
INSERT INTO `data_login` (`NIM`, `password`) VALUES
	('672020001', 'mantap'),
	('672020002', 'mantap'),
	('672020111', 'mantap');
/*!40000 ALTER TABLE `data_login` ENABLE KEYS */;

-- Dumping structure for table database_mahasiswa.data_mahasiswa
CREATE TABLE IF NOT EXISTS `data_mahasiswa` (
  `NIM` char(9) COLLATE utf8_bin NOT NULL,
  `Nama` varchar(100) COLLATE utf8_bin NOT NULL,
  `Asal` varchar(255) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`NIM`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- Dumping data for table database_mahasiswa.data_mahasiswa: ~3 rows (approximately)
/*!40000 ALTER TABLE `data_mahasiswa` DISABLE KEYS */;
INSERT INTO `data_mahasiswa` (`NIM`, `Nama`, `Asal`) VALUES
	('672020001', 'JOHN DOE', 'JAKARTA SELATAN'),
	('672020002', 'INDRO HUSNA', 'KOTA PADANG'),
	('672020111', 'PAIJO PANGESTU', 'KOTA SALATIGA');
/*!40000 ALTER TABLE `data_mahasiswa` ENABLE KEYS */;

-- Dumping structure for table database_mahasiswa.data_matakuliah
CREATE TABLE IF NOT EXISTS `data_matakuliah` (
  `KodeMakul` varchar(6) COLLATE utf8_bin NOT NULL,
  `NamaMakul` varchar(100) COLLATE utf8_bin NOT NULL,
  `SKSA` tinyint(4) NOT NULL DEFAULT '0',
  `SKSB` tinyint(4) NOT NULL DEFAULT '0',
  `Progdi` varchar(100) COLLATE utf8_bin NOT NULL DEFAULT '0',
  PRIMARY KEY (`KodeMakul`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- Dumping data for table database_mahasiswa.data_matakuliah: ~3 rows (approximately)
/*!40000 ALTER TABLE `data_matakuliah` DISABLE KEYS */;
INSERT INTO `data_matakuliah` (`KodeMakul`, `NamaMakul`, `SKSA`, `SKSB`, `Progdi`) VALUES
	('IN112', 'PENGANTAR TEKNIK INFORMATIKA', 3, 4, '67'),
	('IN212', 'SISTEM BASIS DATA', 6, 7, '67'),
	('IN315', 'PEMROGRAMAN BEORIENTASI PLATFORM', 3, 3, '67');
/*!40000 ALTER TABLE `data_matakuliah` ENABLE KEYS */;

-- Dumping structure for table database_mahasiswa.data_nilai
CREATE TABLE IF NOT EXISTS `data_nilai` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Semester` char(5) COLLATE utf8_bin NOT NULL DEFAULT '20121',
  `SerialJadwal` int(11) NOT NULL,
  `NIM` char(9) COLLATE utf8_bin NOT NULL,
  `Nilai` varchar(2) COLLATE utf8_bin NOT NULL DEFAULT 'DT',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- Dumping data for table database_mahasiswa.data_nilai: ~0 rows (approximately)
/*!40000 ALTER TABLE `data_nilai` DISABLE KEYS */;
/*!40000 ALTER TABLE `data_nilai` ENABLE KEYS */;

-- Dumping structure for table database_mahasiswa.data_progdi
CREATE TABLE IF NOT EXISTS `data_progdi` (
  `KodeProgdi` char(2) COLLATE utf8_bin NOT NULL,
  `NamaProgdi` varchar(100) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`KodeProgdi`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- Dumping data for table database_mahasiswa.data_progdi: ~2 rows (approximately)
/*!40000 ALTER TABLE `data_progdi` DISABLE KEYS */;
INSERT INTO `data_progdi` (`KodeProgdi`, `NamaProgdi`) VALUES
	('67', 'TEKNIK INFORMATIKA'),
	('68', 'SISTEM INFORMASI'),
	('69', 'DESAIN KOMUNIKASI VISUAL');
/*!40000 ALTER TABLE `data_progdi` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
