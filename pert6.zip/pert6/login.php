<!doctype html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<link rel="stylesheet" href="css/bootstrap.min.css">
		<title>Login Page</title>
	</head>
	<body>
		<br><br>
<?php

session_start();
include_once "fungsi.php";
$err = "";
if (isset($_POST['login'])) {
	$user = isset($_POST['user']) ? $_POST['user'] : '';
	$pass = isset($_POST['pass']) ? $_POST['pass'] : '';
	
	if ($user != "" && $pass != "") {
		if (cekLogin($user,$pass)) {
			$_SESSION['jeneng'] = $user;
			$_SESSION['data'] = getDataMahasiswa($user);
		} else {
			$err = '<div class="alert alert-danger"><b>USERNAME/PASSWORD SALAH!!!</b></div>';
		}
	}
}

if (isset($_SESSION['jeneng'])) {
	header("location:index.php");
	exit;
}

echo '
	<div class="container-fluid">
		'.$err.'
		<form method="post">
			<table class="table table-bordered">
				<tr>
					<th class="table-info">Username</th>
					<td><input class="form-control" type="text" name="user"></td>
				</tr>
				<tr>
					<th class="table-info">Password</th>
					<td><input class="form-control" type="password" name="pass"></td>
				</tr>
				<tr>
					<td colspan="2"><input class="btn btn-success" type="submit" name="login" value="Login"></td>
				</tr>
			</table>
		</form>
	</div>
';
require_once "footer.php";
?>