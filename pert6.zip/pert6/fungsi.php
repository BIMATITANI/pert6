<?php
include_once "config.php";

$semester = '20191';

function cekLogin($user = "", $pass = "")
{
	global $conn;

	$sql = "SELECT * FROM data_login WHERE NIM = '$user' and password = '$pass'";
	$result = mysqli_query($conn, $sql);

	if (mysqli_num_rows($result) > 0) {
		return true;
	} else {
		return false;
	}
}

function getHari($hari = 1)
{
	if ($hari == 1) return "SENIN";
	else if ($hari == 2) return "SELASA";
	else if ($hari == 3) return "RABU";
	else if ($hari == 4) return "KAMIS";
	else if ($hari == 5) return "JUMAT";
	else if ($hari == 6) return "SABTU";
	else if ($hari == 7) return "MINGGU";
	else return "SENIN";
}

function getListKelasMakulTersedia($kodemk)
{
	global $conn, $semester;
	$data = array();

	$sql = "SELECT j.Serial, j.KodeMakul, m.NamaMakul, m.SKSA, m.SKSB, j.KodeKelas, Hari, Jam1, Jam2, Ruang, MaxKursi, (SELECT COUNT(*) FROM data_list_peserta WHERE SerialJadwal = j.Serial) KursiTerambil, KodeDosen, (SELECT NamaDosen FROM data_dosen WHERE KodeDosen = j.KodeDosen) NamaDosen
			FROM data_jadwal j
			INNER JOIN data_matakuliah m ON m.KodeMakul = j.KodeMakul
			WHERE Semester = '$semester' AND j.KodeMakul = '$kodemk'";
	$result = mysqli_query($conn, $sql);

	$data = array();
	if (mysqli_num_rows($result) > 0) {
		$i = 0;
		while ($row = mysqli_fetch_array($result)) {
			$data[$i]['Serial'] = $row['Serial'];
			$data[$i]['KodeMakul'] = $row['KodeMakul'];
			$data[$i]['NamaMakul'] = $row['NamaMakul'];
			$data[$i]['SKSA'] = $row['SKSA'];
			$data[$i]['SKSB'] = $row['SKSB'];
			$data[$i]['KodeKelas'] = $row['KodeKelas'];
			$data[$i]['Hari'] = $row['Hari'];
			$data[$i]['Jam1'] = $row['Jam1'];
			$data[$i]['Jam2'] = $row['Jam2'];
			$data[$i]['Ruang'] = $row['Ruang'];
			$data[$i]['KodeDosen'] = $row['KodeDosen'];
			$data[$i]['NamaDosen'] = $row['NamaDosen'];
			$data[$i]['MaxKursi'] = $row['MaxKursi'];
			$data[$i]['SisaKursi'] = $row['MaxKursi'] - $row['KursiTerambil'];
			$i++;
		}
	}

	return $data;
}

function getListRegisMakul()
{
	global $conn, $semester;
	$data = array();

	$sql = "SELECT DISTINCT j.KodeMakul, m.NamaMakul, m.Progdi FROM data_jadwal j
			INNER JOIN data_matakuliah m ON m.KodeMakul = j.KodeMakul
			WHERE Semester = '$semester' ORDER BY KodeMakul";
	$result = mysqli_query($conn, $sql);
	if (mysqli_num_rows($result) > 0) {
		$i = 0;
		while ($row = mysqli_fetch_array($result)) {
			$data[$i]['KodeMakul'] = $row['KodeMakul'];
			$data[$i]['NamaMakul'] = $row['NamaMakul'];
			$data[$i]['Progdi'] = $row['Progdi'];
			$i++;
		}
	}

	return $data;
}

function getPeserta($kodemakul)
{
	global $conn, $semester;
	$data = array();

	$sql = "SELECT Serial, KodeMakul, KodeKelas FROM data_jadwal WHERE KodeMakul = '$kodemakul' AND Semester = '$semester' ORDER BY KodeMakul, KodeKelas";
	$result = mysqli_query($conn, $sql);

	$data = array();
	if (mysqli_num_rows($result) > 0) {
		while ($row = mysqli_fetch_array($result)) {
			$sql2 = "SELECT p.NIM, (SELECT Nama FROM data_mahasiswa WHERE NIM = p.NIM) Nama FROM data_list_peserta p WHERE SerialJadwal = " . $row['Serial'] . " ORDER BY NIM ASC";
			$result2 = mysqli_query($conn, $sql2);

			if (mysqli_num_rows($result2) > 0) {
				$i = 0;
				while ($row2 = mysqli_fetch_array($result2)) {
					$data[$row['KodeKelas']][$i]['NIM'] = $row2['NIM'];
					$data[$row['KodeKelas']][$i]['Nama'] = $row2['Nama'];
					$i++;
				}
			}
		}
	}

	return $data;
}

function getKSTMahasiswa($nim)
{
	global $conn, $semester;
	$data = array();

	$sql = "SELECT p.NIM, p.Status, p.SerialJadwal, p.Id, j.KodeMakul, j.KodeKelas, j.Hari, j.Jam1, j.Jam2, j.Ruang, j.KodeDosen, (SELECT NamaDosen FROM data_dosen WHERE KodeDosen = j.KodeDosen) NamaDosen, m.NamaMakul, m.SKSA, m.SKSB
			FROM data_list_peserta p 
			INNER JOIN data_jadwal j ON j.Serial = p.SerialJadwal
			INNER JOIN data_matakuliah m ON m.KodeMakul = j.KodeMakul
			WHERE Semester = '$semester' AND NIM = '$nim'";
	$result = mysqli_query($conn, $sql);

	$data = array();
	if (mysqli_num_rows($result) > 0) {
		$i = 0;
		while ($row = mysqli_fetch_array($result)) {
			$data[$i]['Id'] = $row['Id'];
			$data[$i]['NIM'] = $row['NIM'];
			$data[$i]['Status'] = $row['Status'];
			$data[$i]['SerialJadwal'] = $row['SerialJadwal'];
			$data[$i]['KodeMakul'] = $row['KodeMakul'];
			$data[$i]['KodeKelas'] = $row['KodeKelas'];
			$data[$i]['NamaMakul'] = $row['NamaMakul'];
			$data[$i]['Hari'] = $row['Hari'];
			$data[$i]['Jam1'] = $row['Jam1'];
			$data[$i]['Jam2'] = $row['Jam2'];
			$data[$i]['Ruang'] = $row['Ruang'];
			$data[$i]['KodeDosen'] = $row['KodeDosen'];
			$data[$i]['NamaDosen'] = $row['NamaDosen'];
			$data[$i]['SKSA'] = $row['SKSA'];
			$data[$i]['SKSB'] = $row['SKSB'];
			$i++;
		}
	}

	return $data;
}

function getNamaMakul($kode)
{
	global $conn;

	$sql = "SELECT NamaMakul FROM data_matakuliah WHERE KodeMakul = '$kode'";
	$result = mysqli_query($conn, $sql);
	if (mysqli_num_rows($result) > 0) {
		$row = mysqli_fetch_array($result);
		return $row['NamaMakul'];
	}
	return '-';
}

function insertDataMahasiswa($data)
{
	global $conn;

	$nim = $data['NIM'];
	$nama = $data['Nama'];
	$asal = $data['Asal'];
	$sql = "INSERT INTO data_mahasiswa (NIM, Nama, Asal) VALUES ('$nim','$nama','$asal')";
	if (mysqli_query($conn, $sql)) {
		return true;
	} else {
		return false;
	}
}

function updateDataMahasiswa($data)
{
	global $conn;

	$nim = $data['NIM'];
	$nama = $data['Nama'];
	$asal = $data['Asal'];
	$sql = "UPDATE data_mahasiswa SET Nama = '$nama', Asal = '$asal' WHERE NIM = '$nim'";
	if (mysqli_query($conn, $sql)) {
		return true;
	} else {
		return false;
	}
}

function deleteDataMahasiswa($nim)
{
	global $conn;

	$sql = "DELETE FROM data_mahasiswa WHERE NIM = '$nim'";
	if (mysqli_query($conn, $sql)) {
		return true;
	} else {
		return false;
	}
}

function getDataMahasiswa($nim)
{
	global $conn;

	$sql = "SELECT NIM, Nama, Asal FROM data_mahasiswa WHERE NIM = '$nim'";
	$result = mysqli_query($conn, $sql);

	$data = array();
	if (mysqli_num_rows($result) > 0) {
		$row = mysqli_fetch_array($result);
		$data['NIM'] = $row['NIM'];
		$data['Nama'] = $row['Nama'];
		$data['Asal'] = $row['Asal'];
	}

	return $data;
}

function getAllDataMahasiswa()
{
	global $conn;

	$sql = "SELECT NIM, Nama, Asal FROM data_mahasiswa";
	$result = mysqli_query($conn, $sql);

	$data = array();
	if (mysqli_num_rows($result) > 0) {
		$i = 0;
		while ($row = mysqli_fetch_array($result)) {
			$data[$i]['NIM'] = $row['NIM'];
			$data[$i]['Nama'] = $row['Nama'];
			$data[$i]['Asal'] = $row['Asal'];
			$i++;
		}
	}

	return $data;
}

function hapusKST($id)
{
	global $conn;
	$sql = "DELETE FROM data_list_peserta WHERE Id = '$id'";

	if (mysqli_query($conn, $sql)) {
		return true;
	} else {
		return false;
	}
}

function ambilMakul($serial, $nim)
{

	global $conn;

	$status = 'B';
	$sql = "INSERT INTO data_list_peserta (id, SerialJadwal, NIM, Status) VALUES (null,'$serial','$nim', '$status')";

	if (mysqli_query($conn, $sql)) {
		return true;
	} else {
		return false;
	}
}


function cekAmbil($serial, $nim)
{
	global $conn;

	$sql = 'SELECT * FROM data_list_peserta WHERE SerialJadwal = ' . $serial . ' AND NIM = ' . $nim . '';
	$res = mysqli_query($conn, $sql);
	if (mysqli_num_rows($res) > 0) {
		return true;
	} else {
		return false;
	}
}

function cekKursi($serial)
{
	global $conn;

	$sql = 'SELECT MaxKursi - (SELECT COUNT(*) FROM data_list_peserta WHERE SerialJadwal = ' . $serial . ') sisa_kursi FROM data_jadwal WHERE Serial = ' . $serial . '';
	$res = mysqli_query($conn, $sql);

	$sisa = mysqli_fetch_row($res);

	if ($res) {
		return $sisa;
	} else {
		return false;
	}
}
