<?php

require_once('fungsi.php');

$res = hapusKST($_GET['id']);

if ($res) {
    header('location:lihat_kst.php');
} else {
    echo 'gagal';
}
