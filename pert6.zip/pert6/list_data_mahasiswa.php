<?php

require_once "header.php";

session_start();

if (!isset($_SESSION['jeneng'])) {
	header("location:login.php");
	exit;
}

include_once "fungsi.php";

if (isset($_GET['edit'])) {
	$nim = isset($_GET['edit']) ? $_GET['edit'] : "";
	$err = array();
	$hasil = '';
	if (strlen($nim) != 9) {
		$err[] = "&bull; Format NIM Salah";
	}
		
	if (!is_numeric($nim)) {
		$err[] = "&bull; Format NIM Salah (Hanya Angka)";
	}
	
	if ($err == NULL) {
		$data = getDataMahasiswa($nim);
		if ($data == NULL) {
			$err[] = "&bull; NIM Tidak Terdaftar";
		}
		
		if ($err == NULL) {
			if (isset($_POST['ganti'])) {
				$inputan = array();
				$inputan['NIM'] = $nim;
				
				$inputan['Nama'] = isset($_POST['Nama']) ? trim(strtoupper($_POST['Nama'])) : "";
				if ($inputan['Nama'] == "") {
					$err[] = "&bull; Nama Harus Diisi";
				}
				
				$inputan['Asal'] = isset($_POST['Asal']) ? trim(strtoupper($_POST['Asal'])) : "";
				if ($inputan['Asal'] == "") {
					$err[] = "&bull; Asal Harus Diisi";
				}
				
				if ($err == NULL) {
					if (updateDataMahasiswa($inputan)) {
						$hasil = '<div class="alert alert-success">Sukses Update Mahasiswa Baru</div>';
						$data = getDataMahasiswa($nim);
					} else {
						$hasil = '<div class="alert alert-danger">Gagal Update Mahasiswa Baru</div>';
					}
					header("Refresh:2; url=list_data_mahasiswa.php");
				} else {
					$hasil = '<div class="alert alert-danger"><h2>Ada Error!!</h2>';
					foreach ($err as $e) {
						$hasil .= '<div>'.$e.'</div>';
					}
					$hasil .= '</div>';
				}
			}
			
			echo '
				<div class="container-fluid">
					'.$hasil.'
					<h2>Edit Data Mahasiswa</h2>
					<form method="post">
						<table class="table table-bordered table-hover">
							<tr>
								<th class="table-info" width="10%" nowrap>NIM</th>
								<td>'.$nim.'</td>
							</tr>
							<tr>
								<th class="table-info" width="10%" nowrap>Nama</th>
								<td><input type="text" class="form-control" name="Nama" value="'.$data['Nama'].'" required></td>
							</tr>
							<tr>
								<th class="table-info" width="10%" nowrap>Asal</th>
								<td><input type="text" class="form-control" name="Asal" value="'.$data['Asal'].'" required></td>
							</tr>
							<tr>
								<td colspan="2"><input type="submit" class="btn btn-warning" name="ganti" value="Ganti"></td>
							</tr>
						</table>
					</form>
				</div>
			';
		} else {
			$hasil = '<div class="alert alert-danger"><h2>Ada Error!!</h2>';
				foreach ($err as $e) {
					$hasil .= '<div>'.$e.'</div>';
				}
			$hasil .= '</div>';
			echo $hasil;
		}
	}
	echo '<a href="list_data_mahasiswa.php">KEMBALI</a>';
} else {
	$hasil = '';
	if (isset($_POST['tambah'])) {
		$err = array();
		$inputan = array();
		$inputan['NIM'] = isset($_POST['NIM']) ? $_POST['NIM'] : "";
		if (strlen($inputan['NIM']) != 9) {
			$err[] = "&bull; Format NIM Salah";
		}
		
		if (!is_numeric($inputan['NIM'])) {
			$err[] = "&bull; Format NIM Salah (Hanya Angka)";
		}
		
		$inputan['Nama'] = isset($_POST['Nama']) ? trim(strtoupper($_POST['Nama'])) : "";
		if ($inputan['Nama'] == "") {
			$err[] = "&bull; Nama Harus Diisi";
		}
		
		$inputan['Asal'] = isset($_POST['Asal']) ? trim(strtoupper($_POST['Asal'])) : "";
		if ($inputan['Asal'] == "") {
			$err[] = "&bull; Asal Harus Diisi";
		}
		
		if ($err == NULL) {
			if (insertDataMahasiswa($inputan)) {
			$hasil = '<div class="alert alert-success">Sukses Insert Mahasiswa Baru</div>';
			} else {
				$hasil = '<div class="alert alert-danger">Gagal Insert Mahasiswa Baru</div>';
			}
			header("Refresh:2; url=list_data_mahasiswa.php");
		} else {
			$hasil = '<div class="alert alert-danger"><h2>Ada Error!!</h2>';
			foreach ($err as $e) {
				$hasil .= '<div>'.$e.'</div>';
			}
			$hasil .= '</div>';
		}
		
	}

	if (isset($_GET['hapus'])) {
		$nim = $_GET['hapus'];
		if (deleteDataMahasiswa($nim)) {
			$hasil = '<div class="alert alert-success">Sukses Hapus Mahasiswa ('.$nim.')</div>';
		} else {
			$hasil = '<div class="alert alert-danger">Gagal Hapus Mahasiswa  ('.$nim.')</div>';
		}
		header("Refresh:2; url=list_data_mahasiswa.php");
	}

	$list_mhs = '';
	$mhs = getAllDataMahasiswa();
	if (sizeof($mhs) > 0) {
		foreach ($mhs as $val) {
			$list_mhs .= '
				<tr>
					<td width="10%" nowrap><center>'.$val['NIM'].'</center></td>
					<td>'.$val['Nama'].'</td>
					<td>'.$val['Asal'].'</td>
					<th width="10%" nowrap>
					<center>
						<a href="list_data_mahasiswa.php?edit='.$val['NIM'].'" class="btn btn-warning">EDIT</a> &nbsp; 
						<a href="list_data_mahasiswa.php?hapus='.$val['NIM'].'" class="btn btn-danger">X</a>
					</center>
					</th>
				</tr>
			';
		}
	} else {
		$list_mhs = '<tr class="table-danger"><td colspan="4">No Data</td></tr>';
	}

	echo '
			
			<div class="container-fluid">
				'.$hasil.'
				<h2>Insert Data Mahasiswa</h2>
				<form method="post">
					<table class="table table-bordered table-hover">
						<tr>
							<th class="table-info" width="10%" nowrap>NIM</th>
							<td><input type="text" class="form-control" name="NIM" minlength="9" maxlength="9" required></td>
						</tr>
						<tr>
							<th class="table-info" width="10%" nowrap>Nama</th>
							<td><input type="text" class="form-control" name="Nama" required></td>
						</tr>
						<tr>
							<th class="table-info" width="10%" nowrap>Asal</th>
							<td><input type="text" class="form-control" name="Asal" required></td>
						</tr>
						<tr>
							<td colspan="2"><input type="submit" class="btn btn-success" name="tambah" value="Tambahkan"></td>
						</tr>
					</table>
				</form>
				<hr>
				<h2>List Data Mahasiswa</h2>
				<table class="table table-bordered table-hover">
					<tr class="table-success">
						<th width="10%" nowrap><center>NIM</center></th>
						<th>Nama</th>
						<th>Kota Asal</th>
						<th width="10%" nowrap><center>#</center></th>
					</tr>
					'.$list_mhs.'
				</table>
			</div>
	';
}



require_once "footer.php";
?>