<?php

require_once "header.php";

session_start();

if (!isset($_SESSION['jeneng'])) {
	header("location:login.php");
	exit;
}

include_once "fungsi.php";


$list_kst = '';
$kst = getKSTMahasiswa($_SESSION['data']['NIM']);
if (sizeof($kst) > 0) {
	$i = 0;
	$totsksa = 0;
	$totsksb = 0;
	foreach ($kst as $val) {
		if (strlen($val['Jam1']) <= 1) $jam1 = "0" . $val['Jam1'];
		else $jam1 = $val['Jam1'];
		if (strlen($val['Jam2']) <= 1) $jam2 = "0" . $val['Jam2'];
		else $jam2 = $val['Jam2'];
		$jam = $jam1 . '_' . $jam2;

		$i++;
		$list_kst .= '
			<tr>
				<td width="5%" nowrap><center>' . $i . '</center></td>
				<td width="5%" nowrap><center>' . $val['KodeMakul'] . $val['KodeKelas'] . '</center></td>
				<td>' . $val['NamaMakul'] . '</td>
				<td width="5%" nowrap><center>' . $val['Status'] . '</center></td>
				<td width="5%" nowrap><center>' . $val['SKSA'] . '</center></td>
				<td width="5%" nowrap><center>' . $val['SKSB'] . '</center></td>
				<td width="20%" nowrap>
					<div><b>' . $val['KodeDosen'] . '</b></div>
					<div>' . $val['NamaDosen'] . '</div>
					<div>' . $val['Ruang'] . '</div>
					<div>' . getHari($val['Hari']) . '</div>
					<div>' . $jam . '</div>
				</td>
				<td width="5%" nowrap><center><a href="hapusKST.php?id=' . $val['Id'] . '">HAPUS</a></center></td> <!-- TAMBAHKAN HAPUS DARI KST -->
			</tr>
		';
		$totsksa += $val['SKSA'];
		$totsksb += $val['SKSB'];
	}
	$list_kst .= '
	<tr>
		<td colspan="3">&nbsp;</span></td>
		<th width="5%" nowrap><center>Total</center></th>
		<th width="5%" nowrap><center>' . $totsksa . '</center></th>
		<th width="5%" nowrap><center>' . $totsksb . '</center></th>
		<td>&nbsp;</td>
		<td>&nbsp;</td>
	</tr>';
} else {
	$list_kst = '<tr class="table-danger"><td colspan="8">No Data</td></tr>';
}
echo '
			
		<div class="container-fluid">
			<h2>Kartu Studi Tetap</h2>
			<table class="table table-bordered table-hover">
				<tr class="table-success">
					<th width="5%" nowrap><center>No</center></th>
					<th width="5%" nowrap><center>Kode</center></th>
					<th>Matakuliah</th>
					<th width="5%" nowrap><center>Status</center></th>
					<th width="5%" nowrap><center>SKSA</center></th>
					<th width="5%" nowrap><center>SKSB</center></th>
					<th width="10%" nowrap>Keterangan</th>
					<th width="5%" nowrap><center>&nbsp;</center></th>
				</tr>
				' . $list_kst . '
			</table>
			<button class="btn btn-info">DOWNLOAD KST</button><!-- TAMBAHIN DOWNLOAD KST (PDF) -->
		</div>
	';


require_once "footer.php";
