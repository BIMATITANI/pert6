<?php

require_once "header.php";

session_start();

if (!isset($_SESSION['jeneng'])) {
	header("location:login.php");
	exit;
}

echo '
		
		<div class="container-fluid">
			<h2>Welcome '.$_SESSION['data']['Nama'].'</h2>
		</div>
';

require_once "footer.php";
?>
