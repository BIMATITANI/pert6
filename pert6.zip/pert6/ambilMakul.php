<?php
require_once('fungsi.php');
session_start();
if (cekAmbil($_GET['serial'], $_SESSION['data']['NIM']) && cekKursi($_GET['serial']) > 0) {
    //berati udah ambil kelasnya
    header('location:regis_makul.php');
} else {
    $res = ambilMakul($_GET['serial'], $_SESSION['data']['NIM']);

    if ($res) {
        header('location:lihat_kst.php');
    } else {
        echo 'gagal';
    }
}
