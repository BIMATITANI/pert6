<?php

require_once "header.php";

session_start();

if (!isset($_SESSION['jeneng'])) {
	header("location:login.php");
	exit;
}

include_once "fungsi.php";

$menu = isset($_GET['menu']) ? $_GET['menu'] : "";

if ($menu == "cek1") {
	$kodemk = isset($_GET['kodemk']) ? $_GET['kodemk'] : "";
	echo '
		<div class="container-fluid">
			<h2>Registrasi Matakuliah</h2>
	';
	$nama_makul = getNamaMakul($kodemk);
	if ($nama_makul == "-") {
		echo '<div class="alert alert-danger"><h3>TIDAK ADA DATA</h3></div>';
	} else {
		$list_regis_makul = "";
		$data_regis = getListKelasMakulTersedia($kodemk);
		if (sizeof($data_regis) > 0) {
			echo '
				<table class="table table-bordered table-hover">	
					<tr class="table-success">
						<th width="5%" nowrap><center>Kode</center></th>
						<th>Matakuliah</th>
						<th width="5%" nowrap><center>SKSA</center></th>
						<th width="5%" nowrap><center>SKSB</center></th>
						<th>Keterangan</th>
					</tr>
			';
			foreach ($data_regis as $val) {
				if (strlen($val['Jam1']) <= 1) $jam1 = "0" . $val['Jam1'];
				else $jam1 = $val['Jam1'];
				if (strlen($val['Jam2']) <= 1) $jam2 = "0" . $val['Jam2'];
				else $jam2 = $val['Jam2'];
				$jam = $jam1 . '_' . $jam2;

				echo '
					<tr>
						<td width="5%" nowrap><center><a href="ambilMakul.php?serial=' . $val['Serial'] . '">' . $val['KodeMakul'] . $val['KodeKelas'] . '</a></center></td> <!-- saat klik ini = ambil -->
						<td>' . $val['NamaMakul'] . ' ' . $val['KodeKelas'] . '</td>
						<td width="5%" nowrap><center>' . $val['SKSA'] . '</center></td>
						<td width="5%" nowrap><center>' . $val['SKSB'] . '</center></td>
						<td>
							<div><b>' . $val['KodeDosen'] . '</b></div>
							<div>' . $val['NamaDosen'] . '</div>
							<div>' . $val['Ruang'] . '</div>
							<div>' . getHari($val['Hari']) . '</div>
							<div>' . $jam . '</div>
							<div>Sisa Kursi : ' . $val['SisaKursi'] . '</div>
						</td>
					</tr>
				';
			}
			echo '
				</table>
			';
		} else {
			echo '<div class="alert alert-danger"><h3>TIDAK ADA DATA</h3></div>';
		}
	}
} else if ($menu == "peserta") {
	$peserta = isset($_GET['peserta']) ? $_GET['peserta'] : "";

	echo '
		<div class="container-fluid">
			<h2>Daftar Peserta Matakuliah</h2>
	';
	$nama_makul = getNamaMakul($peserta);
	if ($nama_makul == "-") {
		echo '<div class="alert alert-danger"><h3>TIDAK ADA DATA</h3></div>';
	} else {
		$list_peserta = "";
		$data_peserta = getPeserta($peserta);
		if (sizeof($data_peserta) > 0) {
			foreach ($data_peserta as $kode_kelas => $data_peserta) {
				$i = 0;
				$list_peserta .= '
					<table class="table table-bordered table-hover">
						<tr class="table-success">
							<th width="5%" nowrap><center>#</center></th>
							<th width="5%" nowrap><center>' . $peserta . $kode_kelas . '</center></th>
							<th>' . $nama_makul . ' ' . $kode_kelas . '</th>
						</tr>
				';
				foreach ($data_peserta as $val) {
					$i++;
					if ($val['NIM'] == $_SESSION['data']['NIM']) {
						$list_peserta .= '
							<tr style="color:red;">
								<th width="5%" nowrap><center>' . $i . '</center></th>
								<th width="5%" nowrap><center>' . $val['NIM'] . '</center></th>
								<th>' . $val['Nama'] . '</th>
							</tr>
						';
					} else {
						$list_peserta .= '
							<tr>
								<td width="5%" nowrap><center>' . $i . '</center></td>
								<td width="5%" nowrap><center>' . $val['NIM'] . '</center></td>
								<td>' . $val['Nama'] . '</td>
							</tr>
						';
					}
				}
				$list_peserta .= '
					</table>
				';
			}
			echo $list_peserta;
		} else {
			echo '<div class="alert alert-danger"><h3>TIDAK ADA DATA</h3></div>';
		}
	}
	echo '
		</div>
	';
} else if ($menu == "") {
	$list_regis_makul = '';

	$data = getListRegisMakul();
	if (sizeof($data) > 0) {
		$i = 0;
		foreach ($data as $val) {
			$i++;
			$list_regis_makul .= '
				<tr>
					<td width="5%" nowrap><center><a href="regis_makul.php?menu=cek1&kodemk=' . $val['KodeMakul'] . '">' . $val['KodeMakul'] . '</a></center></td>
					<td>' . $val['NamaMakul'] . '</td>
					<td width="5%" nowrap><center><a href="regis_makul.php?menu=peserta&peserta=' . $val['KodeMakul'] . '">PESERTA</a></center></td>
				</tr>
			';
		}
	} else {
		$list_regis_makul = '<tr class="table-danger"><td colspan="3">No Data</td></tr>';
	}
	echo '
		<div class="container-fluid">
			<h2>Registrasi Matakuliah</h2>
			<table class="table table-bordered table-hover">
				<tr class="table-success">
					<th width="5%" nowrap><center>#</center></th>
					<th>Matakuliah</th>
					<th width="5%" nowrap><center>&nbsp;</center></th>
				</tr>
				' . $list_regis_makul . '
			</table>
		</div>
	';
}

require_once "footer.php";
