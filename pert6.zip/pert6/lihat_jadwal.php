<?php

require_once "header.php";

session_start();

if (!isset($_SESSION['jeneng'])) {
	header("location:login.php");
	exit;
}

include_once "fungsi.php";

$peserta = isset($_GET['peserta']) ? $_GET['peserta'] : "";

if ($peserta != "") {
	echo '
		<div class="container-fluid">
			<h2>Daftar Peserta Matakuliah</h2>
	';
	$nama_makul = getNamaMakul($peserta);
	if ($nama_makul == "-") {
		echo '<div class="alert alert-danger"><h3>TIDAK ADA DATA</h3></div>';
	} else {
		$list_peserta = "";
		$data_peserta = getPeserta($peserta);
		if (sizeof($data_peserta) > 0) {
			echo '';
			foreach ($data_peserta as $kode_kelas => $data_peserta) {
				$i = 0;
				$list_peserta .= '
					<table class="table table-bordered table-hover">
						<tr class="table-success">
							<th width="5%" nowrap><center>#</center></th>
							<th width="5%" nowrap><center>'.$peserta.$kode_kelas.'</center></th>
							<th>'.$nama_makul.' '.$kode_kelas.'</th>
						</tr>
				';
				foreach ($data_peserta as $val) {
					$i++;
					if ($val['NIM'] == $_SESSION['data']['NIM']) {
						$list_peserta .= '
							<tr style="color:red;">
								<th width="5%" nowrap><center>'.$i.'</center></th>
								<th width="5%" nowrap><center>'.$val['NIM'].'</center></th>
								<th>'.$val['Nama'].'</th>
							</tr>
						';
					} else {
						$list_peserta .= '
							<tr>
								<td width="5%" nowrap><center>'.$i.'</center></td>
								<td width="5%" nowrap><center>'.$val['NIM'].'</center></td>
								<td>'.$val['Nama'].'</td>
							</tr>
						';
					}
					
				}
				$list_peserta .= '
					</table>
				';
			}
			echo $list_peserta;
		} else {
			echo '<div class="alert alert-danger"><h3>TIDAK ADA DATA</h3></div>';
		}
	}
	echo '
		</div>
	';
} else if ($peserta == "") {
	$list_jadwal = '';
	$kst = getKSTMahasiswa($_SESSION['data']['NIM']);
	if (sizeof($kst) > 0) {
		$i = 0;
		foreach ($kst as $val) {
			if (strlen($val['Jam1']) <= 1) $jam1 = "0".$val['Jam1'];
			else $jam1 = $val['Jam1'];
			if (strlen($val['Jam2']) <= 1) $jam2 = "0".$val['Jam2'];
			else $jam2 = $val['Jam2'];
			$jam = $jam1.'_'.$jam2;
			
			$i++;
			$list_jadwal .= '
				<tr>
					<td width="5%" nowrap><center>'.$i.'.</center></td>
					<td width="5%" nowrap><center><a href="lihat_jadwal.php?peserta='.$val['KodeMakul'].'">'.$val['KodeMakul'].$val['KodeKelas'].'</a></center></td>
					<td>'.$val['NamaMakul'].'</td>
					<td width="5%" nowrap><center>'.$val['KodeDosen'].'</center></td>
					<td><center>'.$val['NamaDosen'].'</center></td>
					<td width="5%" nowrap><center>'.getHari($val['Hari']).'</center></td>
					<td width="5%" nowrap><center>'.$jam.'</center></td>
					<td width="5%" nowrap><center>'.$val['Ruang'].'</center></td>
				</tr>
			';
		}
	} else {
		$list_jadwal = '<tr class="table-danger"><td colspan="8">No Data</td></tr>';
	}
	echo '
		<div class="container-fluid">
			<h2>Jadwal Kuliah</h2>
			<table class="table table-bordered table-hover">
				<tr class="table-success">
					<th width="5%" nowrap><center>No</center></th>
					<th width="5%" nowrap><center>Kode</center></th>
					<th>Matakuliah</th>
					<th width="5%" nowrap><center>Kode Dosen</center></th>
					<th><center>Nama Dosen</center></th>
					<th width="5%" nowrap><center>Hari</center></th>
					<th width="5%" nowrap><center>Jam</center></th>
					<th width="5%" nowrap><center>Ruang</center></th>
				</tr>
				'.$list_jadwal.'
			</table>
		</div>
	';
}

require_once "footer.php";
?>