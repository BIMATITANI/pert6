<!doctype html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<link rel="stylesheet" href="css/bootstrap.min.css">
		<title>Hello, world!</title>
	</head>
	<body>
		<nav class="navbar navbar-expand-lg sticky-top navbar-dark bg-dark">
			<a class="navbar-brand" href="index.php">Home</a>
			<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navCol" aria-controls="navbarColor01" aria-expanded="false" aria-label="Toggle navigation">
				<span class="navbar-toggler-icon"></span>
			</button>
			<div class="collapse navbar-collapse" id="navCol">
				<ul class="navbar-nav mr-auto">
					<li class="nav-item">
						<a class="nav-link" href="regis_makul.php">Registrasi Matakuliah</a>
					</li>
					<li class="nav-item">
						<a class="nav-link" href="lihat_jadwal.php">Jadwal Kuliah</a>
					</li>
					<li class="nav-item">
						<a class="nav-link" href="lihat_kst.php">KST</a>
					</li>
					<li class="nav-item">
						<a class="nav-link" href="">Hasil Studi</a>
					</li>
					<li class="nav-item">
						<a class="nav-link" href="">Transkrip Nilai</a>
					</li>
				</ul>
				<ul class="navbar-nav">	
					<li class="nav-item">
						<a class="nav-link" href="logout.php">Logout</a>
					</li>
				</ul>
			</div>
		</nav>